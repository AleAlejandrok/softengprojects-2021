package cen4010.pa3;

public class tictactoe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Board b = new Board(3);
		GUI g= new GUI();
		g.setDefaultCloseOperation(0);
		
		
	}

}
